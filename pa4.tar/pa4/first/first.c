#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

size_t reads = 0;
size_t writes = 0;
size_t hits = 0;
size_t misses = 0;
size_t preads = 0;
size_t pwrites = 0;
size_t phits = 0;
size_t pmisses = 0;


struct listnode {
	size_t tag;
	int valid;
	size_t fi;
};

void performOperation(char operation, double blockBytes, int assoc, int numSets, size_t newhex, struct listnode ***incache){
	int x;
	struct listnode **cache=*incache;
	
	// first find block offest

	int blockOffset;
	blockOffset = log2(blockBytes);
	// find index offset
	int index = log2(numSets);
	// tag offset
	//int tagbits = 48 - blockOffset - index;
	
	// extract tag and index
	size_t tagHex, indexHex;
	tagHex = newhex>>((blockOffset) + (index));
	//printf("tagHex: %zx\n", tagHex);
	indexHex = (newhex>>(blockOffset)) % (size_t)(pow(2, (index)));
	//printf("INDEXHEX: %zx\n", indexHex);
	
	//printf("numSets: %d\n", numSets);
	//printf("assoc: %d\n", assoc);
	
	
	// check hit or miss.
	
	int hit = 0;
	for(x = 0; x < assoc; x++){
		if(cache[indexHex][x].tag == tagHex){
			//printf("Checking Hit\n");
			hit = 1;
			// its a hit. check if its a read or a write. return after this?
			if((operation == 'r') || (operation == 'R')){
				hits++;
				x = assoc;
			}
			if((operation == 'w') || (operation == 'W')){
				hits++;
				writes++;
				x = assoc;
			}
		}
	}
	//printf("hit: %d\n", hit);
	
	// miss
	if(hit == 0){
		//printf("Checking Miss\n");
		if((operation == 'r') || (operation == 'R')){
			misses++;
			reads++;
			// insert into cache
			int full = 1;
			int x;
			for(x = 0; x < assoc; x++){
				if(cache[indexHex][x].valid == 0){
					full = 0;
					cache[indexHex][x].tag = tagHex;
					cache[indexHex][x].valid = 1;
					x = assoc;
				}
			}
			if(full == 1){
				//printf("Checking Full\n");
				cache[indexHex][cache[indexHex][0].fi].tag = tagHex;
				cache[indexHex][cache[indexHex][0].fi].valid = 1;
				//int i;
				//printf("fi: %zd\n", cache[indexHex][0].fi);
				if((cache[indexHex][0].fi) == (assoc - 1)){
					cache[indexHex][0].fi = 0;
				}else{
					cache[indexHex][0].fi = (cache[indexHex][0].fi) + 1;
					//printf("new fi: %zd\n", cache[indexHex][0].fi);
				}
			}
			
		}
		if((operation == 'w') || (operation == 'W')){
			misses++;
			reads++;
			writes++;
			int full = 1;
			int x;
			for(x = 0; x < assoc; x++){
				if(cache[indexHex][x].valid == 0){
					full = 0;
					cache[indexHex][x].tag = tagHex;
					cache[indexHex][x].valid = 1;
					x = assoc;
				}
			}
			if(full == 1){
				//printf("Checking Full\n");
				cache[indexHex][cache[indexHex][0].fi].tag = tagHex;
				cache[indexHex][cache[indexHex][0].fi].valid = 1;
				//int i;
				//printf("fi: %zd\n", cache[indexHex][0].fi);
				if((cache[indexHex][0].fi) == (assoc - 1)){
					cache[indexHex][0].fi = 0;
				}else{
					cache[indexHex][0].fi = (cache[indexHex][0].fi) + 1;
					//printf("new fi: %zd\n", cache[indexHex][0].fi);
				}
			}
		}
	}
}

void performOperation1(char operation1, double blockBytes1, int assoc1, int numSets1, size_t newhex1, struct listnode ***incache1){
	int x;
	struct listnode **cache1 = *incache1;
	
	// first find block offest

	int blockOffset;
	blockOffset = log2(blockBytes1);
	//printf("block offset: %d\n", blockOffset);
	//printf("%d ", assoc);
	// find index offset
	int index = log2(numSets1);
	//printf("index bits: %d\n", index);
	// tag offset
	//int tagbits = 48 - blockOffset - index;
	//printf("tagbits: %d\n", tagbits);
	
	// extract tag and index
	
	//printf("size_t input: %zx\n", newhex);
	size_t tagHex, indexHex;
	tagHex = newhex1>>((blockOffset) + (index));
	//printf("tagHex: %zx\n", tagHex);
	indexHex = (newhex1>>(blockOffset)) % (size_t)(pow(2, (index)));
	//printf("INDEXHEX: %zx\n", indexHex);
	
	//printf("numSets: %d\n", numSets);
	//printf("assoc: %d\n", assoc);
	
	
	// check hit or miss.
	
	int hit = 0;
	for(x = 0; x < assoc1; x++){
		if(cache1[indexHex][x].tag == tagHex){
			//printf("Checking Hit\n");
			hit = 1;
			// its a hit. check if its a read or a write. return after this?
			if((operation1 == 'r') || (operation1 == 'R')){
				phits++;
				x = assoc1;
			}
			if((operation1 == 'w') || (operation1 == 'W')){
				phits++;
				pwrites++;
				x = assoc1;
			}
		}
	}
	//printf("hit: %d\n", hit);
	
	// miss
	
	if(hit == 0){
		size_t prefetchHex = newhex1 + blockBytes1;
		size_t preTagHex, preIndexHex;
		preTagHex = prefetchHex>>((blockOffset) + (index));
		preIndexHex = (prefetchHex>>(blockOffset)) % (size_t)(pow(2, (index)));
		//printf("Checking Miss\n");
		//printf("indexHex: %zd\n", indexHex);
		//printf("preIndexHex: %zd\n", preIndexHex);
		
		if((operation1 == 'r') || (operation1 == 'R')){
			pmisses++;
			preads++;
			// insert address into cache
			int full = 1;
			int full1 = 1;
			int x;
			for(x = 0; x < assoc1; x++){
				if(cache1[indexHex][x].valid == 0){
					full = 0;
					cache1[indexHex][x].tag = tagHex;
					cache1[indexHex][x].valid = 1;
					x = assoc1;
				}
			}
			if(full == 1){
				//printf("Checking Full\n");
				cache1[indexHex][cache1[indexHex][0].fi].tag = tagHex;
				cache1[indexHex][cache1[indexHex][0].fi].valid = 1;
				//int i;
				//printf("fi: %zd\n", cache1[indexHex][0].fi);
				if((cache1[indexHex][0].fi) == (assoc1 - 1)){
					cache1[indexHex][0].fi = 0;
				}else{
					cache1[indexHex][0].fi = (cache1[indexHex][0].fi) + 1;
					//printf("new fi: %zd\n", cache1[indexHex][0].fi);
				}
			}
			
			// insert prefetched address into cache
			
			int present = 0;
			for(x = 0; x < assoc1; x++){
				if(cache1[preIndexHex][x].tag == preTagHex){
					present = 1;
				}
			}
			if(present == 0){
				preads++;
				for(x = 0; x < assoc1; x++){
					if(cache1[preIndexHex][x].valid == 0){
						full1 = 0;
						cache1[preIndexHex][x].tag = preTagHex;
						cache1[preIndexHex][x].valid = 1;
						x = assoc1;
					}
				}
				if(full1 == 1){
					//printf("Checking Full\n");
					cache1[preIndexHex][cache1[preIndexHex][0].fi].tag = preTagHex;
					cache1[preIndexHex][cache1[preIndexHex][0].fi].valid = 1;
					//int i;
					//printf("fi: %zd\n", cache1[preIndexHex][0].fi);
					if((cache1[preIndexHex][0].fi) == (assoc1 - 1)){
						cache1[preIndexHex][0].fi = 0;
					}else{
						cache1[preIndexHex][0].fi = (cache1[preIndexHex][0].fi) + 1;
						//printf("new fi: %zd\n", cache1[preIndexHex][0].fi);
					}
				}
			}
			
		}
		if((operation1 == 'w') || (operation1 == 'W')){
			pmisses++;
			preads++;
			pwrites++;
			int full = 1;
			int full1 = 1;
			int x;
			for(x = 0; x < assoc1; x++){
				if(cache1[indexHex][x].valid == 0){
					full = 0;
					cache1[indexHex][x].tag = tagHex;
					cache1[indexHex][x].valid = 1;
					x = assoc1;
				}
			}
			if(full == 1){
				//printf("Checking Full\n");
				cache1[indexHex][cache1[indexHex][0].fi].tag = tagHex;
				cache1[indexHex][cache1[indexHex][0].fi].valid = 1;
				//int i;
				//printf("fi: %zd\n", cache1[indexHex][0].fi);
				if((cache1[indexHex][0].fi) == (assoc1 - 1)){
					cache1[indexHex][0].fi = 0;
				}else{
					cache1[indexHex][0].fi = (cache1[indexHex][0].fi) + 1;
					//printf("new fi: %zd\n", cache1[indexHex][0].fi);
				}
			}
			
			// insert prefetched address into cache
			
			int present = 0;
			for(x = 0; x < assoc1; x++){
				if(cache1[preIndexHex][x].tag == preTagHex){
					present = 1;
				}
			}
			if(present == 0){
				preads++;
				for(x = 0; x < assoc1; x++){
					if(cache1[preIndexHex][x].valid == 0){
						full1 = 0;
						cache1[preIndexHex][x].tag = preTagHex;
						cache1[preIndexHex][x].valid = 1;
						x = assoc1;
					}
				}
				if(full1 == 1){
					//printf("Checking Full\n");
					cache1[preIndexHex][cache1[preIndexHex][0].fi].tag = preTagHex;
					cache1[preIndexHex][cache1[preIndexHex][0].fi].valid = 1;
					//int i;
					//printf("fi: %zd\n", cache1[preIndexHex][0].fi);
					if((cache1[preIndexHex][0].fi) == (assoc1 - 1)){
						cache1[preIndexHex][0].fi = 0;
					}else{
						cache1[preIndexHex][0].fi = (cache1[preIndexHex][0].fi) + 1;
						//printf("new fi: %zd\n", cache1[preIndexHex][0].fi);
					}
				}
			}
		}
	}
}


int main(int argc, char** argv){
// ./first 32 assoc:2 fifo 4 trace2.txt
	if(argc != 6){
		printf("not enough arguments\n");
		return 0;
	}
	
	FILE *fp;
	fp = fopen(argv[5], "r");

	if(fp == NULL){
		return 0;
	}
	int temp1 = atoi(argv[4]);
	double blockBytes = (double)temp1;
	while(temp1 % 2 == 0){
		temp1 = temp1/2;
	}
	if(temp1 != 1){
		printf("error");
		return 0;
	}
	//printf("blockBytes: %lf", blockBytes);
	//printf("temp1: %d", temp1);
	char *array = argv[2];
	int size = strlen(array);
	int assoc, numSets;
	//printf("%s ", array);
	//printf("%c ", array[6]);
	if((size != 7) && (size != 6) && (size != 5)){
		printf("error");
		return 0;
	}
	int checkCache = atoi(argv[1]);
	while(checkCache % 2 == 0){
		checkCache = checkCache/2;
	}
	if(checkCache != 1){
		printf("error");
		return 0;
	}
	if(size == 7){
		assoc = atoi(&array[6]);
		int tempAssoc = assoc;
		while(tempAssoc % 2 == 0){
			tempAssoc = tempAssoc/2;
		}
		if(tempAssoc != 1){
			printf("error");
			return 0;
		}
		//printf("assoc: %d ", assoc);
		int keep = assoc * blockBytes;
		//printf("keep: %d", keep);
		int cachesize = atoi(argv[1]);
		//printf("cachesize: %d", cachesize);
		numSets = cachesize/keep;
		//printf("numSets: %d", numSets);
	}
	if(size == 6){
		assoc = 1;
		int keep = assoc * blockBytes;
		//printf("keep: %d", keep);
		int cachesize = atoi(argv[1]);
		//printf("cachesize: %d", cachesize);
		numSets = cachesize/keep;
		//printf("numSets: %d", numSets);
	}
	if(size == 5){
		int cachesize = atoi(argv[1]);
		numSets = 1;
		int keep = blockBytes * numSets;
		assoc = cachesize/keep;
	}
	char hold;
	char operation;
	size_t newhex;
	
	//printf("Testing, %d\n", operation);
	
	// create cache
	
	struct listnode **cache = (struct listnode**) malloc(sizeof(struct listnode*)*numSets);
	int i;
	for(i = 0; i < numSets; i++){
		/*struct listnode *newNode = NULL;
		newNode = (struct listnode *)malloc(sizeof(struct listnode));
		cache[newNode] = i;*/
		cache[i] = (struct listnode*) malloc(sizeof(struct listnode)*assoc);
	}
	int x;
	//int count = 0;
	for(i = 0; i < numSets; i++){
		for(x = 0; x < assoc; x++){
			struct listnode *newNode = (struct listnode *) malloc(sizeof(struct listnode));
			//newNode->fi = count++;
			cache[i][x] = *newNode;
		}
	}
	
	for(i = 0; i < numSets; i++){
		cache[i][0].fi = 0;
		//printf("Set: %d\n", i);
		//printf("fi: %zd\n", cache[i][0].fi);
		for(x = 0; x < assoc; x++){
			cache[i][x].valid = 0;
			//printf("valid: %d\n", cache[i][x].valid);
		}
	}
	
	// create cache 1
	
	struct listnode **cache1 = (struct listnode**) malloc(sizeof(struct listnode*)*numSets);
	for(i = 0; i < numSets; i++){
		/*struct listnode *newNode = NULL;
		newNode = (struct listnode *)malloc(sizeof(struct listnode));
		cache[newNode] = i;*/
		cache1[i] = (struct listnode*) malloc(sizeof(struct listnode)*assoc);
	}
	//int count = 0;
	for(i = 0; i < numSets; i++){
		for(x = 0; x < assoc; x++){
			struct listnode *newNode = (struct listnode *) malloc(sizeof(struct listnode));
			//newNode->fi = count++;
			cache1[i][x] = *newNode;
		}
	}
	
	for(i = 0; i < numSets; i++){
		cache1[i][0].fi = 0;
		//printf("Set: %d\n", i);
		//printf("fi: %zd\n", cache[i][0].fi);
		for(x = 0; x < assoc; x++){
			cache1[i][x].valid = 0;
			//printf("valid: %d\n", cache[i][x].valid);
		}
	}
	
	// end of creating cache1	
	
	// get input from file
	while(fscanf(fp, "%c", &hold) == 1){
		//printf("Testing");
		if((hold == 'w') || (hold == 'W') || (hold == 'r') || (hold == 'R')){
			operation = hold;
			fscanf(fp, "%zx", &newhex);
			performOperation(operation, blockBytes, assoc, numSets, newhex, &cache);
			performOperation1(operation, blockBytes, assoc, numSets, newhex, &cache1);
		}
	}
	printf("no-prefetch\n");
	printf("Memory reads: %zd\n", reads);
	printf("Memory writes: %zd\n", writes);
	printf("Cache hits: %zd\n", hits);
	printf("Cache misses: %zd\n", misses);
	printf("with-prefetch\n");
	printf("Memory reads: %zd\n", preads);
	printf("Memory writes: %zd\n", pwrites);
	printf("Cache hits: %zd\n", phits);
	printf("Cache misses: %zd\n", pmisses);
	
	
	return 0;
}
